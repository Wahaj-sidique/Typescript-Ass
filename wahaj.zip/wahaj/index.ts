interface Post {
    id: number;
    userId: number;
    title: string;
    body: string;
  }
  
  function fetchPosts(): Promise<Post[]> {
    return fetch('https://jsonplaceholder.typicode.com/posts')
      .then((response) => response.json())
      .then((data) => data);
  }
  
  function createTableHeader(table: HTMLTableElement, headers: string[]) {
    const row = table.insertRow();
    headers.forEach((header) => {
      const cell = row.insertCell();
      cell.innerHTML = header;
    });
  }
  
  function createTableRow(table: HTMLTableElement, values: any[]) {
    const row = table.insertRow();
    values.forEach((value) => {
      const cell = row.insertCell();
      cell.innerHTML = value;
    });
  }
  
  function createDataTable(posts: Post[]) {
    const table = document.getElementById('data-table') as HTMLTableElement;
    createTableHeader(table, ['ID', 'User ID', 'Title', 'Body']);
    posts.forEach((post) => {
      createTableRow(table, [post.id, post.userId, post.title, post.body]);
    });
  }
  
  async function main() {
    const posts = await fetchPosts();
    createDataTable(posts);
  }
  
  main();